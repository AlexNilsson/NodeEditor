/* global FLOW */


/**
 * Sets a Node's functional properties
 * 
 * @param   {String} node_id 
 * @param   {Object} data
 * @returns {undefined}
 */
FLOW.setNodeProperties = function( node_id, data ){
    
    FLOW.nodeProperties[node_id] = data;
    
};



/**
 * Returns a Node's functional properties
 * 
 * @param   {String} node_id 
 * @returns {Object}
 */
FLOW.getNodeProperties = function( node_id ){

    return FLOW.nodeProperties[node_id] || {};

};



/**
 * Loads a flow into the scene and initiates the node editor
 * 
 * @param   {String <JSON>} data
 * @returns {undefined}
 */
FLOW.loadData = function( data ){

    if ( typeof data === "string" ) {

        FLOW.nodes          = [];
        FLOW.connections    = [];
        FLOW.nodeProperties = [];

        //* To prevent a dom-selection bug new id's needs to be assigned to nodes and connectors
        //* this object keeps track of these changes while instanciating the components
        FLOW.ID_MAP = {};

        var data = JSON.parse( data );


        //* CANVAS TRANSFORM
        CANVAS.zoomValue = data.flow.canvas_zoom;

        var _canvasTranslation = JSON.parse( data.flow.canvas_translation );
        CANVAS.translation = new Vector2D( _canvasTranslation.x, _canvasTranslation.y );


        //* NODES
        data.flow_steps.forEach( function( node ){
            
            var connectors = JSON.parse( node.attributes.connectors );
            connectors = connectors.map( function( args ){

                args.id = undefined;

                args.position = new Vector2D( args.position.x, args.position.y );
                args.target = new Vector2D( args.target.x, args.target.y );

                if ( args.connection !== undefined ) {

                    var newId = UTILITY.randomId();

                    FLOW.ID_MAP[ args.connection ] = newId;

                    args.connection = newId;
                }

                return new Connector( args ); 
            });

            var buttons = JSON.parse( node.attributes.buttons );
            buttons = buttons.map( function( args ){ 
                
                args.id = undefined;

                args.position = new Vector2D( args.position.x, args.position.y );

                return new Button( args.action, args );
            });

            var _pos = JSON.parse( node.attributes.position );
            var position = new Vector2D( _pos.x, _pos.y );

            var _socket = JSON.parse( node.attributes.socket );
            var socket = new Vector2D( _socket.x, _socket.y );

            var nodeInstance = new Node({
                "type":               node.step_type,
                "shape":              node.attributes.shape,
                "icon":               node.attributes.icon,
                "title":              node.attributes.title,
                "subTitle":           node.attributes.subtitle,
                "connectors":         connectors,
                "tags":               JSON.parse( node.attributes.tags ),
                "allowedConnections": JSON.parse( node.attributes.allowed_connections ),
                "position":           position,
                "configured":         node.attributes.configured,
                "socket":             socket,
                "buttons":            buttons,
                "color":              node.attributes.color
            });

            FLOW.nodes.push( nodeInstance );

            FLOW.ID_MAP[ node.internal_id ] = nodeInstance.id;

            FLOW.nodeProperties[nodeInstance.id] = node.properties;

            CANVAS.OVERLAY.hide();

            FLOW.updateState();

        });


        //* CONNECTIONS
        data.flow_transitions.forEach( function( connection ){
            FLOW.connections.push( new Connection(
                FLOW.ID_MAP[ connection.source_id ],
                FLOW.ID_MAP[ connection.target_id ],
                {
                    "id": FLOW.ID_MAP[ connection.internal_id ],
                    "event": connection.transition_type,
                    "color": FLOW.CONNECTION_EVENT_COLORS[connection.transition_type]
                }
            ));

            FLOW.updateState();
        });

        FLOW.init();
    }
    else {
        console.error( "Could not load Flow: invalid data format" );
    }
};



/**
 *  Loads a flow into the scene and initiates
 *  the node editor in "published mode"
 * 
 * @param   {String <JSON>} data
 * @returns {undefined}
 */
FLOW.show = function( data ){

    var scope = this;

    scope.isPublished = true;
    
    NODELIST.hide();
    
    scope.loadData( data );

};



/**
 *  Loads a flow into the scene and initiates
 *  the node editor in "edit mode"
 * 
 * @param   {String <JSON>} data
 * @returns {undefined}
 */
FLOW.edit = function( data ){
    
    var scope = this;

    scope.isPublished = false;
    
    NODELIST.show();
    
    scope.loadData( data );

};



/**
 * Returns all flow data as a JSON string
 * 
 * @param   {String} flow_name the name to call the flow
 * @returns {String <JSON>}
 */
FLOW.getData = function( flow_name ){
    
    var _nodes = [];
    var _connections = [];

    FLOW.nodes.forEach( function( node ) {
        _nodes.push({
            "step_type":            node.type,
            "internal_id":          node.getId(),
            "attributes" : {
                "shape":                node.shape,
                "icon":                 node.icon,
                "title":                node.title,
                "subtitle":             node.subTitle,
                "connectors":           JSON.stringify( node.connectors ),
                "tags":                 JSON.stringify( node.tags ),
                "allowed_connections":  JSON.stringify( node.allowedConnections ),
                "position":             JSON.stringify( node.position ),
                "configured":           node.configured,
                "socket":               JSON.stringify( node.socket ),
                "buttons":              JSON.stringify( node.buttons ),
                "color":                node.color
            },
            "properties":           FLOW.getNodeProperties( node.id )
        });
    });

    FLOW.connections.forEach( function( connection ) {
        _connections.push({
            "internal_id":      connection.id,
            "transition_type":  connection.event,
            "source_id":        FLOW.getNode(connection.source).getId(),
            "target_id":        FLOW.getNode(connection.target).getId()
        });
    });


    var first_trigger = FLOW.nodes
        .filter( function( node ){ return node.type.split("_")[0] === "trigger"; } )
        .map( function( node ){ return node.getId(); })[0];

    var flow = {
        name: flow_name,
        canvas_zoom: CANVAS.zoomValue,
        canvas_translation: JSON.stringify( CANVAS.translation ),
        initial_step_id: first_trigger || ""
    };

    var data = {
        flow: flow,
        flow_steps: _nodes,
        flow_transitions: _connections
    };
    
    return JSON.stringify(data);
};